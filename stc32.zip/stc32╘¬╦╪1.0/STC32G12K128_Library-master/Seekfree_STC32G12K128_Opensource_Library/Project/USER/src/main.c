#include "Include.h"
#include "main.h"
float I_Kp=1100 ,I_Kd=100;//800 200 //850 350 //9500 400����
float V_Kp_L=0,V_Ki_L=0.1,   V_Kp_R=0.1,V_Ki_R=0.1;//220 35 �ջ�
uint8 text[]={1,2,35};int i;
extern float VeL_actual ,VeR_actual ;//isr calcu
extern float now_ecL,last_ecL,now_ecR,last_ecR;
extern my fg;//���ķ��� == ð�� û���� ��������
#define VeR_set 2000
#define VeL_set 2000
void State_Init()
{
	fg.chujie=0;
	fg.qishiwei=0;fg.qscount_1=0;fg.qscount_2=0;
	fg.jifen=0;
	fg.menu_open=1;//�˵�
	fg.podao_1=0;fg.podao_2=0,fg.podao_3=0;//�µ�
	fg.sudu_huan=0;fg.sudu_huan_2=0;//�ٶȻ�
	fg.guiyi_hua=1;//��й�һ��
	fg.yhcountL_1=0;fg.yhcountL_2=0;fg.yhcountL_3=0;fg.yhcountL_4=0,fg.yhcountL_5=0;//��Բ��
	fg.yhcountR_1=0;fg.yhcountR_2=0;fg.yhcountR_3=0;fg.yhcountR_4=0,fg.yhcountR_5=0;//��Բ��
	fg.stop_1=0;fg.stop_2=0;fg.stop_3=0;fg.already_ru=0,fg.stop_ph_1=0;//���
	fg.go_1=0;fg.go_2=0;fg.go_3=0,fg.already_chu=0,fg.go_ph_1=0;//����
}
uint32 datlen;uint8 temp=20;
void main()
{
	EA=0;
	board_init();		
	All_Init();	bee=0;
	EA=1;
	Inductor_Scan();
    while(1)
{
	 send_to_computer();
	datlen=bluetooth_ch9141_read_buff(&temp,100);
	if(datlen==1)V_Kp_L=V_Kp_L+0.01;
	if(datlen==2)V_Ki_L=V_Ki_L+0.01;
	
//	if(datlen==1)I_Kp++;
//	if(datlen==2)I_Kd++;
//	if(datlen==1)I_Kp++;
	
	
	//if(fg.menu_open==1){}
//if(boma2==0)Inductance_show();//State_Show();//menu_main();//// //Inductance_show();  // 
//		Sudu_Huan_PD_deburg();			Get_Gyroval();//Inductor_Getval();
//	qishiwei_panduan();
//	chu_ku();
//	podao();
//	yuan_huanL();
//if((fg.already_chu==1)&&(fg.already_ru==0)) MotorDone_Control(2000,2000);
//     ru_ku();

		Sudu_Huan_2(2000,0);//2/1024 
		//CarForward(2000,2000);//3000 3000 �ջ�	
}
}




//Velocity_Calu(); Sudu_Huan(2000,2000);Get_Gyroval();
//Inductor_Getval();CarForward(2000,2000);bluetooth_ch9141_send_buff((uint8*)&Vr,sizeof(Vr));
void All_Init()
{
	State_Init();lcd_init();
	pwm_init(A_in_1, 17000, 0); //��ʼ��PWM1  ʹ��P60����  ��ʼ��Ƶ��Ϊ17Khz
	pwm_init(A_in_2, 17000, 0); //��ʼ��PWM2  ʹ��P62����  ��ʼ��Ƶ��Ϊ17Khz
	pwm_init(B_in_1, 17000, 0); //��ʼ��PWM1  ʹ��P60����  ��ʼ��Ƶ��Ϊ17Khz
	pwm_init(B_in_2, 17000, 0); //��ʼ��PWM2  ʹ��P62����  ��ʼ��Ƶ��Ϊ17Khz
	adc_init(Port_L1,ADC_SYSclk_DIV_2);//AD_L
	adc_init(Port_L2,ADC_SYSclk_DIV_2);//AD_R
	adc_init(Port_L3,ADC_SYSclk_DIV_2);//AD_M
	gpio_pull_set(P7_0,PULLUP); gpio_pull_set(P7_1,PULLUP); //key 
	gpio_pull_set(P7_2,PULLUP); gpio_pull_set(P7_3,PULLUP); 
	gpio_pull_set(P7_5,PULLUP); gpio_pull_set(P7_6,PULLUP); 
	gpio_pull_set(P2_6,PULLUP); gpio_mode(P2_6,GPI_OD); 

	gpio_pull_set(P6_7,PULLUP);gpio_mode(P6_7,GPO_PP);
	ctimer_count_init(SPEEDL_PLUSE);	//��ʼ����ʱ��0��Ϊ�ⲿ����
	ctimer_count_init(SPEEDR_PLUSE);	//��ʼ����ʱ��3��Ϊ�ⲿ����
//pit_timer_ms(TIM_1, 10);//pit_timer_ms(TIM_4, 10);
		bluetooth_ch9141_init();icm20602_init();
	
//NVIC_SetPriority(UART4_IRQn, 0);
}




uint8 opt_num[]={0,1,2,3,4,5,6,7,8};                         //ѡ����
uint8 page=1,arrow=0,page_last,open_menu=1,pen_turn=0;
int option;
void key_action()
{
	if((page==1)||(page==22)) option=8; //i��ѡ��                                  
    if(page==22) option=8;
    if(page==24) option=8; 
	if(page==36) option=8; 
    if((key_up)==0)
    {
        if(arrow==1)arrow=(opt_num[option]-1);
        else arrow=arrow-1;
        delay_ms(300);
        lcd_clear(WHITE);
    }
    if((key_down)==0)
    {
        if(arrow==(opt_num[option]-1)) arrow=0;
        else arrow=arrow+1;
        delay_ms(300);
        lcd_clear(WHITE);
    }
}


void menu_main()
{
    if(open_menu==1)
    {
        switch(page)
        {
            case 1 :Menu_show_1();      break;//��һҳ
            case 21:Inductance_show();      break;//��һҳ�����һ��ѡ��
            case 22:PID_velocity_Show();     break;
            case 23:Encode_Show();     break;
            case 24:Gyro_Show();      break;
//			case 25:PID_control();       break;
//			case 26:duoji_show(); break;
//			case 27:ack_test(); break;
//            case 31:qudong_go();        break;
			case 36:Sudu_Huan_PD_deburg();break;
//            default:                    break;
        }
    }
}

void Menu_show_1()//1
{
	page_last=page;
    page=1;
    if(page!=page_last)
    {
        arrow=0;
    }
    key_action();
    lcd_showstr(0,arrow,"->");
    lcd_showstr(20,0,"Inductuor_show");//page 21 enter ֮��
    lcd_showstr(20,1,"PID_show");	//page 22	
    lcd_showstr(20,2,"Encode_Show");//page 23
	lcd_showstr(20,3,"Gyro_Show"); //page  24
//    lcd_showstr(20,4,"velocity");//page 25
//	lcd_showstr(20,5,"distance");//page 26
	
    if((key_enter)==0)
    {
        delay_ms(300);
        lcd_clear(WHITE);
        Menu_show_2();
    }
}

//��������
void Inductance_show()//21
{	
	lcd_showstr(1,0,"AD_L");lcd_showfloat(56,0,AD_L,4,4);
	lcd_showstr(1,1,"AD_M");lcd_showfloat(56,1,AD_M,4,4);
	lcd_showstr(1,2,"AD_R");lcd_showfloat(56,2,AD_R,4,4);
	lcd_showstr(1,3,"Ic_Cret");lcd_showfloat(56,3,Correction,4,4);
	lcd_showstr(1,4,"I_Kp");lcd_showfloat(60,4, I_Kp, 4, 3);
	lcd_showstr(1,5,"I_Kd");lcd_showfloat(60, 5, I_Kd, 4, 3);
	lcd_showstr(20,6,"Actual_VL");lcd_showfloat(95,6, VeL_actual, 4, 1);
	lcd_showstr(20,7,"Actual_VR");lcd_showfloat(95,7, VeR_actual, 4, 1);

	
	
//	lcd_showfloat(56,4,temp1,4,4);lcd_showstr(1,4,"L_chahe");
//	lcd_showfloat(56,5,temp1,4,4);lcd_showstr(1,5,"R_chahe");
//	lcd_showfloat(56,6,temp1,4,4);lcd_showstr(1,6,"M_chahe");
//	lcd_showfloat(75,7,AD_L_Max,4,2);lcd_showstr(1,7,"AD_L_Max");
//	lcd_showfloat(75,8,AD_L_Min,4,2);lcd_showstr(1,8,"AD_L_Min");
}

void PID_velocity_Show()//22	
{	
	key_action();
	lcd_showstr(1,0,"PI_show_deburg");
	lcd_showstr(1,1,"I_Kp");lcd_showfloat(60,1, I_Kp, 4, 3);
	lcd_showstr(1,2,"I_Kd");lcd_showfloat(60, 2, I_Kd, 4, 3);
	lcd_showstr(1,3,"Correction");lcd_showfloat(80, 3, Correction, 4, 2);
	lcd_showstr(1,4,"Out_dutyR");lcd_showfloat(80, 4, Speed_Right, 4, 2);
	lcd_showstr(1,5,"Out_dutyL");lcd_showfloat(80, 5, Speed_Left, 4, 2);

//	if((key_enter)== 0)
//    {
//		Menu_show_3();
//        delay_ms(200);
//        lcd_clear(WHITE);
//    }
//    if((key_return)== 0)
//    {
//        delay_ms(200);
//        lcd_clear(WHITE);
//        Menu_show_1();
//    }
	if(((key_enter)== 0)&&(boma1==1))I_Kp=I_Kp+20;
	if(((key_enter)== 0)&&(boma1==0))I_Kp=I_Kp-20;
	if(((key_down)== 0)&&(boma1==1))I_Kd=I_Kd+2;
	if(((key_down)== 0)&&(boma1==0))I_Kd=I_Kd-2;

	
	
//    if((key_add)== 0)
//    {
//		switch((arrow)+1)
//		{
//			case 1:I_Kp=I_Kp+20;break;
//			case 2:I_Kd=I_Kd+20;break;
//			case 3:duoji.kd=duoji.kd+add_fudu[0];break;
//			case 4:duoji.J=duoji.J+add_fudu[1];break;	
//			case 5:sc_dark=sc_dark+add_fudu[0];break;	
//			case 6:dark=dark+10*add_fudu[0];break;	
//		}
//    }
//    if((key_sub)== 0)
//    {
//		switch((arrow)+1)
//		{
//			case 1:I_Kp=I_Kp+20;break;
//			case 2:I_Kd=I_Kd+20;break;
//			case 3:duoji.kd=duoji.kd-cut_fudu[0];;break;
//			case 4:duoji.J=duoji.J-cut_fudu[1];;break;	
//			case 5:sc_dark=sc_dark-cut_fudu[0];;break;
//			case 6:dark=dark-10*cut_fudu[0];;break;
//		}
//    }	
	
}
void Encode_Show()//case     page 23
{
	key_action();
    lcd_showstr(0,arrow,"->");
	lcd_showstr(20,0,"Home_page");
	lcd_showstr(20,1,"L_pluse");lcd_showfloat(85, 1, L_pluse, 4, 1);
	lcd_showstr(20,2,"Actual_VL");lcd_showfloat(95,2, VeL_actual, 4, 1);
	lcd_showstr(20,3,"R_pluse");lcd_showfloat(85, 3, R_pluse, 4, 1);	
	lcd_showstr(20,4,"Actual_VR");lcd_showfloat(95,4, VeR_actual, 4, 1);
//	lcd_showstr(1,5,"L_DIR");lcd_showfloat(80,5, L_DIR, 4, 2);
//	lcd_showstr(1,6,"R_DIR");lcd_showfloat(80,6, R_DIR, 5, 2);
	lcd_showstr(20,5,"Suduhuan_param");//page 34
	if((key_enter)== 0)
    {
		Menu_show_3();
        delay_ms(300);
        lcd_clear(WHITE);
    }
    if((key_return)== 0)
    {
        delay_ms(300);
        lcd_clear(WHITE);
        Menu_show_1();
    }
}
void Sudu_Huan_PD_deburg()//page 36
{
//	 key_action();
    lcd_showstr(0,arrow,"->");
	lcd_showstr(20,0,"V_Kp_L");lcd_showfloat(80,0,V_Kp_L,3,2);
	lcd_showstr(20,1,"V_Ki_L");lcd_showfloat(80,1,V_Ki_L,3,2);
	lcd_showstr(20,2,"V_Kp_R");lcd_showfloat(80,2,V_Kp_R,3,2);
	lcd_showstr(20,3,"V_Ki_R");lcd_showfloat(80,3,V_Ki_R,3,2);
	lcd_showstr(20,4,"Actual_VL");lcd_showfloat(95,4, VeL_actual, 4, 1);
	lcd_showstr(20,5,"Actual_VR");lcd_showfloat(95,5, VeR_actual, 4, 1);
	lcd_showstr(20,6,"out_purVL");lcd_showfloat(95,6, duty_l, 4, 1);
	lcd_showstr(20,7,"out_purVR");lcd_showfloat(95,7, duty_r, 4, 1);
	
	
	if(((key_enter)== 0)&&(boma1==1))V_Kp_L=V_Kp_L+0.02;
	if(((key_enter)== 0)&&(boma1==0))V_Kp_L=V_Kp_L-0.02;
	if(((key_down)== 0)&&(boma1==1))V_Ki_L=V_Ki_L+0.02;
	if(((key_down)== 0)&&(boma1==0))V_Ki_L=V_Ki_L-0.02;
//		if((key_enter)== 0)
//    {
//		Menu_show_4();
//        delay_ms(300);
//        lcd_clear(WHITE);
//    }
//    if((key_return)== 0)
//    {
//        delay_ms(300);
//        lcd_clear(WHITE);
//        Menu_show_3();
//    }
			
//	   if((key_add)== 0)
//    {
//		switch((arrow)+1)
//		{
//			case 1:V_Kp_L=V_Kp_L+0.2;break;
//			case 1:V_Ki_L=V_Ki_L+0.2;break;
//		}
//    }
//    if((key_sub)== 0)
//    {
//		switch((arrow)+1)
//		{
//			case 1:V_Kp_L=V_Kp_L-0.2;break;
//			case 1:V_Ki_L=V_Ki_L-0.2;break;
//		}
//    }	
	
}


void Gyro_Show()//page 24
{
	lcd_showstr(20,0,"fg.guiyi_hua");lcd_showfloat(80,0,fg.guiyi_hua, 4, 2);
	lcd_showstr(20,1,"gyro_y");lcd_showfloat(80,1,gyro_y, 4, 2);
	lcd_showstr(20,2,"gyro_z");lcd_showfloat(80,2,gyro_z, 4, 2);	
	lcd_showstr(20,3,"acc_x");lcd_showfloat(80,3,acc_x, 4, 2);
	lcd_showstr(20,4,"acc_y");lcd_showfloat(80,4,acc_y, 4, 2);
	lcd_showstr(20,5,"acc_z");lcd_showfloat(80,5,acc_z, 4, 2);		
}
extern uint8 I_P_val,I_D_val;
void State_Show()//page 25
{	 key_action();
	 lcd_showstr(0,arrow,"->");	
	lcd_showstr(20,1,"Huoer");lcd_showfloat(90,1,Huoer,1,1);
	lcd_showstr(20,2,"Guiyi");lcd_showfloat(90,2,fg.guiyi_hua,1,1);
	lcd_showstr(20,3,"qishiwei");lcd_showfloat(90,3,fg.qishiwei,1,1);
	lcd_showstr(20,4,"lanya_P");lcd_showfloat(90,4,I_P_val,1,1);
	lcd_showstr(20,5,"I_Kp");lcd_showfloat(90,5,I_Kp,3,2);
	lcd_showstr(20,6,"datlen");lcd_showfloat(90,6,datlen,3,2);

	
}





void Menu_show_2()//ѡ�� homepage opt
{
    switch((arrow)+1)//����ڶ�ҳ��ǰ��һҳ�ļ�ͷѡ��ѡ��
    {
        case 1:page=21;arrow=0;break;
        case 2:page=22;arrow=0;break;
        case 3:page=23;arrow=0;break;
        case 4:page=24;arrow=0;break;
        case 5:page=25;arrow=0;break;
		case 6:page=26;arrow=0;break;
//		case 7:element=(element>0?0:1);sc.flag_two=1;break;
		case 8:page=27;arrow=0;break;
    }
}

void Menu_show_3()//encoder opt 1-7 ��ѡ��
{
    switch((arrow)+1)
    {
        case 1:page=1;arrow=0;break;//home
//        case 2:page=32;arrow=0;break;
//        case 3:page=33;arrow=0;break;
		case 6:page=36;arrow=0;break;
		
    }
}

void Menu_show_4()
{
    switch((arrow)+1)
    {
        case 1:page=41;arrow=0;break;
        case 2:page=42;arrow=0;break;
		case 3:page=43;arrow=0;break;

    }
}


signed short test1=10;
signed short test2=20;
signed short test3=30;
void send_to_computer()//(signed short int)
{
	signed short datasend[7]={0};//bo[3]={0};
	       datasend[1]=(unsigned short int)VeL_actual;//2000
		   //  datasend[2]=(unsigned short int)duty_r;//3000
	       datasend[3]=(unsigned short int)duty_l;//3000
		     datasend[4]=(unsigned short int)V_Kp_L;//3000
	       datasend[5]=(unsigned short int)V_Ki_L;//3000

		    // datasend[3]=(unsigned short int)gyro_z;
	          Data_Send(datasend);
}