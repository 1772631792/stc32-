#include "Include.h"
//	UART3_RX_P00, UART3_TX_P01,

void Data_Send(unsigned short int *pst)
{
        unsigned char _cnt=0;	unsigned char sum = 0;
		unsigned char i=0;
	unsigned char p=0;
	unsigned char data_to_send[23];         //���ͻ���
	data_to_send[_cnt++]=0xAA;
	data_to_send[_cnt++]=0xAA;
	data_to_send[_cnt++]=0x02;
	data_to_send[_cnt++]=0;
	data_to_send[_cnt++]=(unsigned char)(pst[0]>>8);  //��8λ
	data_to_send[_cnt++]=(unsigned char)pst[0];  //��8λ
	data_to_send[_cnt++]=(unsigned char)(pst[1]>>8);
	data_to_send[_cnt++]=(unsigned char)pst[1];
	data_to_send[_cnt++]=(unsigned char)(pst[2]>>8);
	data_to_send[_cnt++]=(unsigned char)pst[2];
	data_to_send[_cnt++]=(unsigned char)(pst[3]>>8);
	data_to_send[_cnt++]=(unsigned char)pst[3];
	data_to_send[_cnt++]=(unsigned char)(pst[4]>>8);
	data_to_send[_cnt++]=(unsigned char)pst[4];
	data_to_send[_cnt++]=(unsigned char)(pst[5]>>8);
	data_to_send[_cnt++]=(unsigned char)pst[5];
	data_to_send[_cnt++]=(unsigned char)(pst[6]>>8);
	data_to_send[_cnt++]=(unsigned char)pst[6];
	data_to_send[_cnt++]=(unsigned char)(pst[7]>>8);
	data_to_send[_cnt++]=(unsigned char)pst[7];
	data_to_send[_cnt++]=(unsigned char)(pst[8]>>8);
	data_to_send[_cnt++]=(unsigned char)pst[8];
	data_to_send[3] = _cnt-4;
	sum = 0;
	for( i=0;i<_cnt;i++)
		sum += data_to_send[i];
        
	data_to_send[_cnt++] = sum;
        for( p=0;p<_cnt;p++){
		 //uart_putchar(uratn,data_to_send[p]);     
		uart_putchar(UART_4,data_to_send[p]);
		}
       
}





//uart_init(USART_3,UART3_RX_P00,UART3_TX_P01,115200,TIM4);
//	UART3_RX_P00, UART3_TX_P01,
