#ifndef __SHANGWEIJI_H
#define __SHANGWEIJI_H

void Data_Send(unsigned short int *pst);

#endif