#ifndef __YUANSU_H__
#define __YUANSU_H__
void podao();
void qishiwei_panduan();
void chu_ku();
void ru_ku();
void yuan_huanL();


#endif