#ifndef __MOTOR_H__
#define __MOTOR_H__
void CarForward(int16 A_duty,int16 B_duty);//you zuo
void Get_EcVal();//float L_pluse,R_pluse; 
void  Velocity_Calu();
void Sudu_Huan(float Goal_A, float Goal_B);
void Sudu_Huan_2(float Goal_A, float Goal_B); //����ʽ (left,right);




void passive_diff_drive(float angle_error, float* left_speed, float* right_speed, float MAX_SPEED, float WHEEL_DISTANCE);

#endif