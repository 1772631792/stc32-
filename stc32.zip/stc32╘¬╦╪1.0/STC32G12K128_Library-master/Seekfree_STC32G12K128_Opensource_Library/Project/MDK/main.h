#ifndef __MAIN_H__
#define __MAIN_H__
//�Լ�������ⲿ������main.h���������ᵼ�³�ͻ
extern float AD_L,AD_R,AD_M,Kp,Kd,AD_L_Max,AD_L_Min;
extern float temp1,temp2,temp3;
extern int16 Correction,Speed_Right,Speed_Left;
extern float L_pluse,R_pluse,Vr,Vl,duty_l,duty_r; 
extern float timer_count,timestamp;
//extern float acc_x,acc_y,acc_z,gyro_x,gyro_y,gyro_z;
//extern float AD_M_last;
extern float gyro_x,gyro_y,gyro_z,acc_x,acc_y,acc_z;


void All_Init();

void menu_main();
void Menu_show_1();//page 1
void Menu_show_2();
void Menu_show_3();
void Menu_show_4();

void key_action();
void Inductance_show();//page 21

void PID_velocity_Show(); //page 22

void Encode_Show(); //page 23
void Sudu_Huan_PD_deburg();//page 34
	


void Gyro_Show(); //page 24

void send_to_computer();
void State_Show();


#endif