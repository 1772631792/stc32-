#ifndef __INDUCTOR_H__
#define __INDUCTOR_H__

void Inductor_PD(float Kp,float Kd);
void Inductor_Scan();
void smooth_Data(float *input, float *output, int len, int filter_len);
void Inductor_PD(float Kp,float Kd);//*
void MotorDone_Control(float Vr0,float Vl0);
void Inductor_Getval(void);






#endif