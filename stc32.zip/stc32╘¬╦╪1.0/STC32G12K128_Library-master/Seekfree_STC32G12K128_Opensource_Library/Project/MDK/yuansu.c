#include "Include.h"
#include "main.h"
extern my fg;
void podao()
{
		if((AD_L<1.0)&&(AD_M>1.5)&&(AD_R<1.0)) //�µ��ֶδ��� yzhou <-400
	{
			fg.podao_1=1;
			bee=0;//
		while(fg.podao_1){
			CarForward(5000,5000);
			Get_Gyroval();
			if(gyro_y>100)//try jiaosudu
			{
				fg.podao_1=0;
				fg.podao_2=1;
			}				
		}
		while(fg.podao_2)
		{
			CarForward(100,100);
			Inductor_Getval();
			bee=1;
			if((AD_L<0.95)&&(AD_M<0.95)&&(AD_R<0.95))//
			{
				fg.podao_2=0;
				fg.podao_3=1;
			}
		}
		if(fg.podao_3==1) {bee=0;MotorDone_Control(1000,1000);}
		fg.podao_3=0;
	} 
}

void qishiwei_panduan()
{
	if(Huoer==0) fg.qishiwei=1;else fg.qishiwei=0;
}


void chu_ku()
{
	if((fg.qishiwei==0)&&(fg.already_chu==0)) CarForward(1860,1800);	 //����  
	if((fg.qishiwei==1)&&(fg.already_chu==0))//���� �������ػ�
	{
		fg.go_1=1;bee=1;
		fg.already_chu=1;
		while(fg.go_1){fg.go_ph_1++;
			if(fg.go_ph_1==3000)fg.go_ph_1=0;
			CarForward(1000-fg.go_ph_1,-5000+fg.go_ph_1);//�� �� ���
			//Inductor_Scan();
			Inductor_Getval();
				if((AD_L>0.5)&&(AD_M>0.5)&&(AD_R>0.5))
				{
					fg.go_1=0;
					fg.go_2=1;
				}
		}
		if(fg.go_2==1){Inductor_Scan();
			CarForward(2000,2000);
			fg.go_2=0;
		fg.qishiwei=0;	bee=0;	
		}
	}
}

void ru_ku()
{
	//	//���
	if((fg.qishiwei==1)&&(fg.already_ru==0))
	{
		fg.stop_1=1;
		fg.already_ru=1;//���ƺ������ô���
		//if(fg.already_ru==1)//��������λ,�����ת�ĽǶ�
		while(fg.stop_1)
		{	
			fg.stop_ph_1++;
			if(fg.stop_ph_1==3000) fg.stop_ph_1=0;
			CarForward(1000-fg.stop_ph_1,-5000+fg.stop_ph_1);//�� ��
			if((AD_L<0.05)&&(AD_M<0.5)&&(AD_R<0.05))//������ĽǶ���ֵ
			{
				fg.stop_1=0;
				fg.stop_2=1;
			}
		}
		while(fg.stop_2){
		CarForward(800,800);
			if((AD_L<0.05)&&(AD_M<0.1)&&(AD_R<0.05))
			{
				fg.stop_2=0;
				fg.stop_3=1;
			}			
		}
		while(fg.stop_3){
		CarForward(0,0);
		}
	}
}


void yuan_huanL()
{
	//		if((AD_L>1.5)&&(AD_R>1.5)&&(AD_M>1.8)&&(AD_L>AD_R))//Ԥ�뻷 ֮������������ǻ��ָ��� ����
	{		//ǰհ��Բ�����ĵ�
			fg.yhcountL_1=1;
			Inductor_Getval();
			while(fg.yhcountL_1){	
				CarForward(1200,1200);
				Inductor_Getval();
				if((AD_L>1.5)&&(AD_R>1.1)&&(AD_M<1.4)&&(AD_L>AD_R))//�뻷
					{
						bee=1;
						fg.yhcountL_1=0;//***
						fg.yhcountL_2=1;
					}
			}								
			while(fg.yhcountL_2){//�뻷
				bee=0;
				MotorDone_Control(3000,1000);//�� �� ��ת
				//Inductor_Getval();
				if((AD_L<1.1)&&(AD_R<1.0)&&(AD_M<0.95))
				{
					fg.yhcountL_2=0;
					fg.yhcountL_3=1;
				}
			}
			while(fg.yhcountL_3){//����				
					bee=1;
					MotorDone_Control(1500,1500);//ѭ��	
								//Inductor_Getval();			
								if((AD_L>AD_R)&&(AD_M>1.5))//����
								{
								fg.yhcountL_3=0;
								fg.yhcountL_4=1;	
								}
				}
		   while(fg.yhcountL_4){
				bee=1;
					CarForward(1350,1300);//�� ��
					Inductor_Getval();
					if((AD_L<0.9)&&(AD_R<0.9)&&(AD_M<0.9))//����
								{
								fg.yhcountL_4=0;
								fg.yhcountL_5=1;
								}							
				}		   		
			if(fg.yhcountL_5) bee=0;		
			fg.yhcountL_5=0;
		
	}
}
	