#ifndef __SENSOR_H__
#define __SENSOR_H__
#include "math.h"
		 				    

float complementaryFilter(float input, float output, float alpha);
void Get_Gyroval();
float complementaryFilter2(float input, float output, float alpha1, float alpha2);




#endif