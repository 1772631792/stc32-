#include "Include.h"
float AD_L=0,AD_R=0,AD_M=0,AD_M_last=0,AD_R_shu;
float Inductor_Control_val;
float temp1,temp2,temp3;
float last_error=0,now_error=0;
float AD_L_Max=2000,AD_L_Min=0,AD_R_Max=2000,AD_R_Min=0,AD_M_Max=2000,AD_M_Min=0;
float Inductor_cval;extern float I_Kp,I_Kd;
extern my fg;
//ƽ��
#define SAMPLES 10
#define FILTER_LEN 3
float filtered_value1[SAMPLES],filtered_value2[SAMPLES],filtered_value3[SAMPLES];

// ƽ����������
void smooth_sensor(float *input1, float *input2, float *input3, float *output1, float *output2, float *output3, int len, int filter_len)
{
    int i, j;
    float sum1, sum2, sum3;
    for (i = 0; i < len; i++) {
        sum1 = sum2 = sum3 = 0;
        for (j = i; j > i - filter_len; j--) {
            if (j >= 0) {
                sum1 += input1[j];
                sum2 += input2[j];
                sum3 += input3[j];
            }
        }
        output1[i] = sum1 / filter_len;
        output2[i] = sum2 / filter_len;
        output3[i] = sum3 / filter_len;
    }
}

float find_best_value(float *arr, int len) {//zui da zhi
    float best_value = *arr;
    int i;
    for (i = 1; i < len; i++) {
        if (*(arr + i) > best_value) {
            best_value = *(arr + i);
        }
    }
    return best_value;
}


void Inductor_Smooth_Filter()
{
	int i;
	float sensor_raw1[SAMPLES];
	float sensor_raw2[SAMPLES];
	float sensor_raw3[SAMPLES];
	float filtered_value1[SAMPLES];
	float filtered_value2[SAMPLES];
	float filtered_value3[SAMPLES];
	for (i=0;i<SAMPLES;i++)
	{sensor_raw1[i] =adc_once(Port_L1,ADC_12BIT);  }
	for (i=0;i<SAMPLES;i++)
	{ sensor_raw2[i] = adc_once(Port_L2,ADC_12BIT);}
	for (i=0;i<SAMPLES;i++)
	{ sensor_raw3[i] =adc_once(Port_L3,ADC_12BIT);}
	smooth_sensor(sensor_raw1, sensor_raw2, sensor_raw3, filtered_value1, filtered_value2, filtered_value3, SAMPLES, FILTER_LEN);
		
	AD_L=find_best_value(filtered_value1,SAMPLES);
	AD_R=find_best_value(filtered_value2,SAMPLES);
	AD_M=find_best_value(filtered_value3,SAMPLES);

//	for (i=0;i<SAMPLES;i++){AD_L=AD_L+filtered_value1[i];}
//	AD_L=AD_L/SAMPLES;
//	for (i=0;i<SAMPLES;i++){AD_R=AD_R+filtered_value2[i];}
//	AD_R=AD_R/SAMPLES;
//	for (i=0;i<SAMPLES;i++){AD_M=AD_M+filtered_value3[i];}
//	AD_M=AD_M/SAMPLES;
}
	

// ƽ����������
void smooth_Data(float *input, float *output, int len, int filter_len)
{
    int i, j;
    float sum;

    for (i = 0; i < len; i++) {
        sum = 0;
        for (j = i; j > i - filter_len; j--) {
            if (j >= 0) {
                sum += input[j];
            }
        }
        output[i] = sum / filter_len;
    }
}



void Inductor_Getval(void)
{	
		Inductor_Smooth_Filter();
	if(fg.guiyi_hua==1){
	AD_L=(AD_L-AD_L_Min)/(AD_L_Max-AD_L_Min);//
		AD_R=(AD_R-AD_R_Min)/(AD_R_Max-AD_R_Min);//
		AD_M=(AD_M-AD_M_Min)/(AD_M_Max-AD_M_Min);//
	}
	
		
}


void Inductor_PD(float Kp,float Kd)//*
{
	
	Inductor_Smooth_Filter();
	if(fg.guiyi_hua==1){
		AD_L=(AD_L-AD_L_Min)/(AD_L_Max-AD_L_Min);//
		AD_R=(AD_R-AD_R_Min)/(AD_R_Max-AD_R_Min);//
		AD_M=(AD_M-AD_M_Min)/(AD_M_Max-AD_M_Min);//
	}		
	temp1=(AD_M-AD_L)/(AD_M+AD_L);temp2=(AD_M-AD_R)/(AD_M+AD_R);
	now_error=temp1-temp2;
	Inductor_Control_val=(Kp*now_error+Kd*(now_error-last_error));
	last_error=now_error;
}	

void Inductor_Scan()
{
	uint16 AD_L[100],AD_R[100],AD_M[100];
	int i;
	 for(i=0;i<100;i++)  
     {    
       AD_L[i]=adc_once(ADC_L1,ADC_12BIT);//L1  AD_L
       if(AD_L[i]>AD_L_Max) 
	   	 AD_L_Max=AD_L[i];
	   
       if(AD_L[i]<AD_L_Min)
      	 AD_L_Min=AD_L[i];
     } 
	 for(i=0;i<100;i++)  
     { 	  
       AD_R[i]= adc_once(ADC_L2,ADC_12BIT);//L2 AD_R
       if(AD_R[i]>AD_R_Max) 
	   	 AD_R_Max=AD_R[i];
	   
       if(AD_R[i]<AD_R_Min)
      	 AD_R_Min=AD_R[i];
     }	 
	 for(i=0;i<100;i++)  
     { 	   
       AD_M[i]=adc_once(ADC_L3,ADC_12BIT);//L3  AD_M
       if(AD_M[i]>AD_M_Max) 
	   	 AD_M_Max=AD_M[i];
	   
       if(AD_M[i]<AD_M_Min)
      	 AD_M_Min=AD_M[i];
     }
}

int16 Correction=0;
int16 Speed_Right=0,Speed_Left=0;

void MotorDone_Control(float Vr0,float Vl0)
{ 			
	Inductor_PD(10*I_Kp,10*I_Kd);Correction=Inductor_Control_val;
	Speed_Right=Vr0-Correction;Speed_Left=Vl0+Correction;	
	if(Correction>=6500) Correction=6500;
	else if(Correction<=-7000) Correction=-7000;
	if(Speed_Right>=6500) Speed_Right=6500;
	if(Speed_Left>=6500) Speed_Left=6500;
	
//	if(fg.sudu_huan==0) CarForward(Speed_Right,Speed_Left);
//	else if(fg.sudu_huan==1)Sudu_Huan(Speed_Left,Speed_Right);
//		

	if(fg.sudu_huan_2==0) CarForward(Speed_Right,Speed_Left);
	else if(fg.sudu_huan_2==1)Sudu_Huan_2(Speed_Left,Speed_Right);
		
	

	
}


