#ifndef __INCLUDE_H__
#define __INCLUDE_H__
#include "headfile.h"
#include "Inductor.h"
#include "motor.h"
#include "sensor.h"
#include "shangweiji.h"
#include "isr.h"
#include "yuansu.h"
#define ADC_L1  8//AD_L
#define ADC_L2  9  //AD_R
#define ADC_L3  13 //AD_M
#define Port_L1  ADC_P00
#define Port_L2  ADC_P01
#define Port_L3  ADC_P05
//���
#define A_in_1 PWMA_CH3P_P64
#define A_in_2 PWMA_CH4P_P66
#define B_in_1 PWMA_CH1P_P60
#define B_in_2 PWMA_CH2P_P62
//����
#define key_enter P71
#define key_return P70
#define key_down P72
#define key_up P73
//#define key_add P00;
//#define key_sub P10;
#define boma1 P75
#define boma2 P76
//������
#define SPEEDL_PLUSE   CTIM0_P34
#define SPEEDR_PLUSE   CTIM3_P04
//���巽������
#define L_DIR     P35
#define R_DIR     P53
#define bee P67
#define Huoer P26
typedef struct{
	uint8 chujie;
	uint8 qishiwei,qscount_1,qscount_2;
	uint8 jifen;
	uint8 menu_open;
	uint8 guiyi_hua;
	uint8 podao_1,podao_2,podao_3;
	uint8 sudu_huan,sudu_huan_2;
	uint8 yhcountL_1,yhcountL_2,yhcountL_3,yhcountL_4,yhcountL_5;
	uint8 yhcountR_1,yhcountR_2,yhcountR_3,yhcountR_4,yhcountR_5;
	uint8 stop_1,stop_2,stop_3,already_ru;
	uint8 go_1,go_2,go_3,already_chu;
	uint16 go_ph_1,stop_ph_1;//ƽ��ת��
}my;






#endif