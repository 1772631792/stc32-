#include "Include.h"
//uint8 page=1,jiantou=0,page_last,open_menu=1,pen_turn=0;
//uint8 Menu_Num[]={0,1,2,3,4,5,6,7,8};                         //ѡ����

void All_Init();


void main()
{
	DisableGlobalIRQ();	
	All_Init();
	EnableGlobalIRQ();

	while(1)
	{
		Inductor_Scan();

		Encoder_Handle();
		Motor_Deburg_PD();
		MotorDone_Control();
	
	}
}



void All_Init()
{
	board_init();
	lcd_init();
	Motor_Init();
	GPIO_KEY_Init();
//	icm20602_init();
	pit_timer_ms(TIM_0,0.02);
	
//	gpio_pull_set(P6_7,PULLUP);//bee
//	gpio_mode(P6_7,GPI_OD);
	
	   	ctimer_count_init(SPEEDL_PLUSE);	//��ʼ����ʱ��0��Ϊ�ⲿ����
		ctimer_count_init(SPEEDR_PLUSE);	//��ʼ����ʱ��3��Ϊ�ⲿ����

	
	adc_init(ADC_P00,ADC_SYSclk_DIV_2);//AD_L
	adc_init(ADC_P01,ADC_SYSclk_DIV_2);//AD_R
	adc_init(ADC_P05,ADC_SYSclk_DIV_2);//AD_M
//	adc_init(ADC_P06,ADC_SYSclk_DIV_2);//left_P

	 WTST = 0;               //���ó������ȴ���������ֵΪ0�ɽ�CPUִ�г�����ٶ�����Ϊ���
}


//void menu_main()
//{
//    if(open_menu==1)
//    {
//        switch(page)
//        {
//            case 1 :Menu_show_1();      break;
//            case 21:qudong_show();      break;
//            case 22:Inductance_show();     break;
//            case 23:gyro_show();     break;
//            case 24:SPEED_control();      break;
//			case 25:PID_control();       break;
//			case 26:duoji_show(); break;
//			case 27:ack_test(); break;
//            case 31:qudong_go();        break;
//            default:                    break;
//        }
//    }
//}
//void Menu_show_1()
//{
//	
//	page_last=page;
//    page=1;
//    if(page!=page_last)
//    {
//        jiantou=0;
//    }
//    key_action();
//    lcd_showstr(0,jiantou,"->");
//    lcd_showstr(20,0,"qudong_show");
//    lcd_showstr(20,1,"adc");		
//    lcd_showstr(20,2,"gyro-show");
//	lcd_showstr(20,3,"speed-control");
//    lcd_showstr(20,4,"pid-control");
//	lcd_showstr(20,5,"duoji");
//	lcd_showuint8(20,6,element);
//	lcd_showuint8(80,6,sc.flag_two);
//	lcd_showstr(20,7,"ack");
//    if((KEY_A)== 0)
//    {
//        delay_ms(300);
//        lcd_clear(WHITE);
//        Menu_show_2();
//    }
//}

//int guang;
//void key_action()
//{
//    if((page==1)||(page==22))
//        guang=8;                                      //i��ѡ��
//    if(page==21)
//        guang=8;
//    if(page==24)
//        guang=8;
//    if((KEY_U)== 0)
//    {
//        if(jiantou==0)
//        jiantou=(Menu_Num[guang]-1);
//        else
//        jiantou=jiantou-1;
//        delay_ms(200);
//        lcd_clear(WHITE);
//    }
//    if((KEY_D)== 0)
//    {
//        if(jiantou==(Menu_Num[guang]-1))
//        jiantou=0;
//        else
//        jiantou=jiantou+1;
//        delay_ms(200);
//        lcd_clear(WHITE);
//    }
//}

