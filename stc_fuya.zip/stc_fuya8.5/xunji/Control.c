#include "Include.h"
#define V_R0  2500
#define V_L0  2500
float Kp=900,Kd=10000;
extern float Inductor_Control_val;extern float AD_L,AD_R,AD_M;
int16 Correction;
int16 Speed_Right,Speed_Left;
//�ⲿ�����ͽṹ��ֻ���ں�����ʹ��
extern int16 tempL_pluse,tempR_pluse;



void MotorDone_Control()
{
//	Inductor_Control_val=100;
	Inductor_PD(Kp,Kd);
	Correction=10*Inductor_Control_val;
	if(Correction>=6000)
	{
		Correction=6000;
	}
	else if(Correction<=-6000)
	{
		Correction=-6000;
	}

		Speed_Right=V_R0+Correction ;
		Speed_Left=V_L0-Correction ;
	
	if(Speed_Right>=3000) Speed_Right=3000;
	if(Speed_Left>=3000) Speed_Left=3000;

	CarForward(Speed_Right,Speed_Left);
TFT_Show();
}

void Elements_check()
{
	
}


void Motor_Deburg_PD()
{
	
	if(KEY_Read(KEY2)==1)
	{
		Kp=Kp+2;
	}
		if(KEY_Read(KEY3)==1)
	{
		Kp=Kp-2;
	}

		if(KEY_Read(KEY1)==1)
	{
		Kd=Kd+2;
	}
		if(KEY_Read(KEY0)==1)
	{
		Kd=Kd-2;
	}
}

void TFT_Show()
{
	Inductor_Show();
	lcd_showfloat(80, 6, Correction, 4, 4);

	lcd_showfloat(1, 1, Speed_Right, 4, 4);

	lcd_showfloat(20, 7, Kp, 3, 2);
	lcd_showfloat(97, 7, Kd, 4, 0);
}
	
void BEEP_ON()
{
	Bee_Port=1;
}

void BEEP_OFF()
{
	Bee_Port=0;
}