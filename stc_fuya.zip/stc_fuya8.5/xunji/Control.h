
#ifndef __CONTROL_H__
#define __CONTROL_H__

#define Bee_Port P67



void MotorDone_Control();
void Motor_Deburg_PD();
void TFT_Show();
void BEEP_ON();
void BEEP_OFF();

struct Flag
{
	uint8 Ru_huan,Chu_huan;
	uint8 shi_zi,po_dao,che_ku;
	uint8 Ci_Kong;
};

#endif

