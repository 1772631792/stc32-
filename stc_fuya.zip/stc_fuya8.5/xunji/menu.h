#ifndef __MENU_H__
#define __MENU_H__
typedef enum Menu_Page_Enum
{
   MainMenu = 0,
   SubMenu1 = 1,
   SubMenu2 = 2,
   SubMenu3 = 3,
   SubMenu4 = 4,
   SubMenu5 = 5,
   SubMenu6 = 6
} Menu_Page_Enum;



//ҳ��λ������
#define TFT_TOP    0
#define TFT_BUTTOM 7
#define TFT_LEFT   0
#define TFT_RIGHT  127
#define TFT_Line_MIDDLE   63  //���м�


/*****************************/




/***********��������***********/




//ˢ��
void Menu_Refresh(void);
void MainMenu_Refresh(void);
void SubMenu0_Refresh(void);
void SubMenu1_Refresh(void);
void SubMenu2_Refresh(void);
void SubMenu3_Refresh(void);
void SubMenu5_Refresh(void);
void SubMenu6_Refresh(void);
void MenuPointer_Refresh(int Menu_pointer);


#endif