#include "Include.h"


int16 tempL_pluse = 0;
int16 tempR_pluse = 0;

void Encoder_Handle()
{
	//��ȡ�ɼ����ı�����������
        tempL_pluse = ctimer_count_read(SPEEDL_PLUSE);
		tempR_pluse = ctimer_count_read(SPEEDR_PLUSE);

        //����������
        ctimer_count_clean(SPEEDL_PLUSE);
		ctimer_count_clean(SPEEDR_PLUSE);

        //�ɼ�������Ϣ
        if(SPEEDL_DIR==1)    
        {
            tempL_pluse = -tempL_pluse;
        }
        else                  
        {
            tempL_pluse = tempL_pluse;
        }
		if(SPEEDR_DIR==1)    
        {
            tempR_pluse = -tempR_pluse;
        }
        else                  
        {
            tempR_pluse = tempR_pluse;
        }          

}

