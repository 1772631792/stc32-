#ifndef __MOTOR_H__
#define __MOTOR_H__
//void Left_MotorPWM_Set(unsigned char MotorDuty1);//ռ�ձ�Ϊ�ٷ�֮ MotorDuty1/PWM_DUTY_MAX*100
//void Right_MotorPWM_Set(uint8 MotorDuty2);//ռ�ձ�Ϊ�ٷ�֮ MotorDuty2/PWM_DUTY_MAX*100

void Motor_A_RUN(uint8 commond, uint32 MotorDuty2);//��
void Motor_B_RUN(uint8 commond, uint32 MotorDuty1);//��
void Motor_Init();
void CarForward(int16 SpeedA,int16 SpeedB);


#endif