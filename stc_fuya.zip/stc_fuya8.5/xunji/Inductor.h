#ifndef __INDUCTOR_H__
#define __INDUCTOR_H__

//ADC08   P00  L7  right_P
//ADC09   P01  L6  right_V
//ADC13  P05  L2  left_V
//ACD14  P06  L1  left_P

void Inductor_Show();
void Inductor_PD(float Kp,float Kd);
void Inductor_Scan();



#define ADC_L1  8//AD_L
#define ADC_L2  9  //AD_R
#define ADC_L3  13 //ADC_M
#define ADC_L4  14 //ADC_LP

#define Port_L1  ADC_P00
#define Port_L2  ADC_P01
#define Port_L3  ADC_P05
#define Port_L4  ADC_P06


#endif