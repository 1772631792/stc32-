#include "Include.h"
float AD_L,AD_R,AD_M;
float Inductor_Control_val;
float temp1,temp2;
float last_error,now_error;
float AD_L_Max=1000,AD_L_Min=0,AD_R_Max=1000,AD_R_Min=0,AD_M_Max=1000,AD_M_Min=0;

void Inductor_Getval(void)
{
		adc_once(Port_L1,ADC_12BIT);//right_P  8
		adc_once(Port_L2,ADC_12BIT);//right_V  9
		
		adc_once(Port_L3,ADC_12BIT);//left_V   13
		adc_once(Port_L4,ADC_12BIT);//left_P   14
		
		AD_L=(ADC_Read(ADC_L1)-AD_L_Min)/(AD_L_Max-AD_L_Min);//right_P
		AD_R=(ADC_Read(ADC_L2)-AD_R_Min)/(AD_R_Max-AD_R_Min);//right_V
	
		AD_M=(ADC_Read(ADC_L3)-AD_M_Min)/(AD_M_Max-AD_M_Min);//left_V
//		left_P=ADC_Read(ADC_L4);//left_P
	
}


void Inductor_PD(float Kp,float Kd)
{
	Inductor_Getval();
	temp1=(AD_M-AD_L)/(AD_M+AD_L);temp2=(AD_M-AD_R)/(AD_M+AD_R);
	now_error=temp1-temp2;
	last_error=now_error;
	Inductor_Getval();
	temp1=(AD_M-AD_L)/(AD_M+AD_L);temp2=(AD_M-AD_R)/(AD_M+AD_R);
	now_error=temp1-temp2;
	Inductor_Control_val=Kp*now_error+Kd*(now_error-last_error);
}	

void Inductor_Scan()
{
	uint16 AD_L[500],AD_R[500],AD_M[500];
	int i;
	 for(i=0;i<500;i++)  
     { 
	   adc_once(ADC_L1,ADC_12BIT);//L1  AD_L
       AD_L[i]=ADC_Read(Port_L1); 
       if(AD_L[i]>AD_L_Max) 
	   	 AD_L_Max=AD_L[i];
	   
       if(AD_L[i]<AD_L_Min)
      	 AD_L_Min=AD_L[i];
     }
	 
	 for(i=0;i<500;i++)  
     { 
	   adc_once(ADC_L2,ADC_12BIT);//L2 AD_R
       AD_R[i]=ADC_Read(Port_L2); 
       if(AD_R[i]>AD_R_Max) 
	   	 AD_R_Max=AD_R[i];
	   
       if(AD_R[i]<AD_R_Min)
      	 AD_R_Min=AD_R[i];
     }
	 
	 for(i=0;i<500;i++)  
     { 
	   adc_once(ADC_L3,ADC_12BIT);//L3  AD_M
       AD_M[i]=ADC_Read(Port_L3); 
       if(AD_M[i]>AD_M_Max) 
	   	 AD_M_Max=AD_M[i];
	   
       if(AD_M[i]<AD_M_Min)
      	 AD_M_Min=AD_M[i];
     }
}


void Inductor_Show()
{
	lcd_showfloat(56,2,AD_L,4,4);
	lcd_showfloat(56,3,AD_R,4,4);
	lcd_showfloat(60,4,AD_M,4,4);
	lcd_showfloat(60,5,AD_L_Max,4,4);
	lcd_showstr(1,2,"AD_L");
	lcd_showstr(1,3,"AD_R");
	lcd_showstr(1,4,"AD_M");
	lcd_showstr(1,7,"Kp");
	lcd_showstr(80,7,"Kd");
	lcd_showstr(1,6,"Correction");
}





