#ifndef __ENCODER_H__
#define __ENCODER_H__

#define SPEEDL_PLUSE   CTIM0_P34
#define SPEEDR_PLUSE   CTIM3_P04
//���巽������
#define SPEEDL_DIR     P35
#define SPEEDR_DIR     P53
void Encoder_Handle();


#endif